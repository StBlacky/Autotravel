use POSIX qw(strftime);

# ����� ������� == 12000 + ���-�� ������ � ������ �� �������

$arhiv    = "d:/mci/arhiv/";
$konvaexe = "c:\\konva\\konva.exe R /D#DATE# /F#INPUT#";
$konvarnp = "c:\\konva\\rnp\\";
$astradir = "d:\\mci\\astra.osn\\mailbox\\m182\\s\\";
$author   = "4585182000";


$now_date = strftime "%Y-%m-%d", localtime;
$knv_date = strftime "%d.%m.%Y", localtime;
# ������� ������. ���� ��� - ������.

$archdir  = "";
if ($now_date =~ /^(\d\d\d\d)\-(\d\d)\-(\d\d)/) {
  $d3 = $1;
  $d2 = $2;
  $d1 = $3;
  $archdir = $arhiv . "$d3/";
  if (!(-d $archdir)) {
   mkdir($archdir);
  }
  $archdir = $archdir. "$d2/";
  if (!(-d $archdir)) {
   mkdir($archdir);
  }
  $archdir = $archdir. "$d1/";
  if (!(-d $archdir)) {
   mkdir($archdir);
  }
}

@outfiles=glob($archdir . "*");
$coutfiles = $#outfiles;

$edno = 12000 + $coutfiles;
RunQuery("12");
$edno ++;
RunQuery("14");

sub RunQuery {
 $status  = shift(@_);
 $infile  = $archdir . "zapros$edno.xml";
 open(OUT, ">$infile");
 print OUT '<?xml version="1.0" encoding="WINDOWS-1251"?><ED203 xmlns="urn:cbr-ru:ed:v2.0" EDNo="';
 print OUT $edno . '" EDDate="' . $now_date . '" EDAuthor="' . $author;
 print OUT '"  EDReceiver="4583001999" StatusCode="'. $status .'" GroupInquiryCode="2"></ED203>';
 close(OUT);
 $dinfile = $infile;
 $dinfile =~ s/\//\\/g;
 $command = $konvaexe;
 $command =~ s/\#DATE\#/$knv_date/;
 $command =~ s/\#INPUT\#/$dinfile/;
 print "executing: $command\n";
 system($command);

 $doutfile = $astradir;
 $doutfile =~ s/\//\\/g;
 $command  = "move $konvarnp*$edno.ubf $doutfile";
 print "executing: $command\n";
 system($command);
}